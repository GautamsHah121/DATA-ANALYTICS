# Sales-Data-Analysis
## OBJECTIVE:
To Understand how was the Sales of different Items. 
## PROBLEM STATEMENT: 
Sales Management has gained importance to meet increasing competition and the need
for improved methods of distribution to reduce cost and to increase profits. Sales
management today is the most important function in a commercial and business
enterprise.
Do ETL : Extract-Transform-Load some Amazon dataset and find for me
Sales-trend -> month wise , year wise , yearly_month wise
Find key metrics and factors and show the meaningful relationships between attributes.
## DATASET: 
https://docs.google.com/spreadsheets/d/1h3EsPf-fTLrzpP7sGeyuRnGBXrdJRcXY/edit?usp=sharing&ouid=105519103382792804653&rtpof=true&sd=true
## TECHNOLOGY:
Business Intelligence
## DOMAIN:
E-commerce
## PROGRAMMING LANGUAGE:
PYTHON
## TOOLS:
Jupyter Notebook, Power BI, MS Excel
## LINKEDIN: 
https://www.linkedin.com/posts/rahul-gupta-0b10bb21b_analyzing-amazon-sales-data-activity-6914799832943525888-xm6O?utm_source=linkedin_share&utm_medium=member_desktop_web
## VIDEO LINK:
https://youtu.be/JcMVNsBByhY
